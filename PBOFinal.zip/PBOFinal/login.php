<!DOCTYPE html>
<html lang="en">

<head> <?php include 'head.php' ?> </head>

<body>
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="images/icon/Clinic-Logo.png" width="180px" alt="CoolAdmin">
                            </a>
                        </div>
                        <div class="login-form">
                            <?php $submitPath = 'con-pat-regis.php'; ?>
                            <form action="<?php echo $submitPath . "?page=signin"; ?>" method="POST">
                                <div class="form-group">
                                    <label>Username</label>
                                    <input class="au-input au-input--full" type="text" name="username" placeholder="Username">
                                </div>
                                <div class="form-group">
                                    <label>Password</label>
                                    <input class="au-input au-input--full" type="password" name="password" placeholder="Password">
                                </div>
                                <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">sign in</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php' ?>

</body>

</html>
<!-- end document-->