<?php include 'mod-user.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php include "doc-sidebar.php" ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <?php include "header.php" ?>
            <!-- END HEADER DESKTOP-->
            
            <!-- END PAGE CONTAINER-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row form-group">          
                            <div class="col-md-5">
                                <form action="#" method="post"> 
                                    <div class="input-group">
                                        <input class="form-control border-secondary py-2" type="date" placeholder="search" name="sortdate">
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit" name="submitDate">
                                                    Search by Date
                                                </button>
                                            </div>
                                    </div>
                                </form>
                            </div> 
                            <div class="col-md-2">
                                <form action="#" method="post"> 
                                    <div class="input-group">
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit" name="submitName">
                                                    Refresh Table
                                                </button>
                                            </div>
                                    </div>
                                </form>
                            </div> 
                            <div class="col-md-5">
                                <form action="#" method="post"> 
                                    <div class="input-group">
                                        <input class="form-control border-secondary py-2" type="text" placeholder="search" name="sortname" id="sortname">
                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary" type="submit" name="submitName">
                                                    Search by Name
                                                </button>
                                            </div>
                                    </div>
                                </form>
                            </div>  
                                
                        </div>                    
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Medical ID</th>
                                                <th>Patient ID</th>
                                                <th>Full Name</th>
                                                <th>Appointment Date</th>
                                                <th>Description</th>
                                            </tr>
                                        </thead>
                                        <tbody id="myTable">
                                            <?php 
                                            if(isset($_POST['sortdate']) && $_POST['sortdate']!=""){
                                                $getAllData= getMedRecByDate($_POST['sortdate']);
                                            }
                                            else if(isset($_POST['sortname']) && $_POST['sortname']!=""){
                                                $getAllData= getMedRecByName($_POST['sortname']);
                                            }
                                            else {
                                                 $getAllData =getAllMedRecData();
                                            }
                                           
                                            if ($getAllData != null) {
                                                foreach ($getAllData as $data) { ?>
                                                        <tr>
                                                        <td><?php echo $data['MedID'] ?></td>
                                                        <td><?php echo $data['PatientID'] ?></td>
                                                        <td ><?php echo $data['FullName'] ?></td>
                                                        <td><?php echo $data['AppDate'] ?></td>
                                                        <td><?php echo $data['Description'] ?></td>
                                                   <?php 
                                                }
                                            } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

    <?php include "footer.php" ?>
</body>
</html>