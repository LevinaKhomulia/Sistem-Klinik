<?php include 'mod-user.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php include "doc-sidebar.php" ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <?php include "header.php" ?>
            <!-- END HEADER DESKTOP-->

            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <a href="doc-index.php"><img src="images/icon/clinic.png" alt=""></a>
                        </div>
                        <br>
                        <div class="row">
                            <h3>Welcome to One Care Clinic</h3>
                        </div>
                        <br>
                        <div class="row">
                            <h4>Today is <?php echo getTodayDate() ?> </h4>
                        </div>
                        <br>
                        <div class="row">
                            <h4>You have <?php echo countApp() . " patient(s) waiting for you."; ?> </h4>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PAGE CONTAINER-->
        </div>
    </div>

    <?php include "footer.php" ?>

</body>

</html>
<!-- end document-->