<?php

include 'mod-user.php';
include 'asset.php';


if ($_GET['page'] == 'signin') {
    $auth_user = userLogin($_POST['username'], $_POST['password']);
    if (!$auth_user) {
        redirect('login.php');
    } else if ($_POST['username'] == "admin" && $auth_user) {
        redirect('index.php');
    } else if ($_POST['username'] == "doctor" && $auth_user) {
        redirect('doc-index.php');
    }

} else if($_GET['page'] == 'logout') {
    redirect('login.php');

} else if($_GET['page'] == 'regis') {
    if($_POST['Submit'] == 'register')
    {
        if (regisPatient($_POST['pt_name'], $_POST['pt_age'], $_POST['pt_gender'], $_POST['pt_dob'], $_POST['pt_address'])) {
            redirect('index.php');
        } else {
            redirect('user-register.php');
        }
    }

} else if($_GET['page'] == 'app') {
    if($_POST['Submit'] == 'appointment')
    {
        if (appPatient($_POST['pt_app'], $_POST['pt_id'])){
            redirect('index.php');
        } else {
            redirect('user-appointment.php');
        }
    } 

} else if ($_GET['page'] == 'medical') // Doctor
{
    if($_POST['Submit'] == 'medrec')
    {
        if(addMedRec($_POST['pt_date'], $_POST['pt_id'], $_POST['pt_name'], $_POST['pt_desc']) && updateStatus($_POST['pt_id']))
        {
            redirect('doc-index.php');
        } else {
            redirect('add-medrec.php');
        }
    } 

}

?>