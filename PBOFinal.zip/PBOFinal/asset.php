<?php
function redirect($path) {
    header('Location: '.$path);
    die(); 
}
?>