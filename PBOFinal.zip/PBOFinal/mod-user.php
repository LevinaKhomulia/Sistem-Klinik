<?php

function userLogin($_username, $_pass)
{
    include 'config.php';

    $sql = "SELECT * FROM User WHERE Username = '$_username'";

    if ($result = mysqli_query($conn, $sql)) {
        if (mysqli_num_rows($result) <= 0) return false;

        $row = mysqli_fetch_assoc($result);

        if ($_pass == $row['Password']) return true;
        else return false;
    }
}

function getPatientIDNext()
{
    include 'config.php';

    $sql = "SELECT * FROM Patient ORDER BY patientID desc LIMIT 1";

    if ($result = mysqli_query($conn, $sql)) {
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $idNext = sprintf("%'.05d", (int)$row["PatientID"] + 1);
        } else {
            $idNext = "00001";
        }
    }
    return $idNext;
}

function regisPatient($fullname, $age, $gender, $dob, $address)
{
    include 'config.php';

    $idNext = getPatientIDNext();

    $appointment = "none";

    $status = "none";

    $sql = "INSERT INTO Patient VALUES ('$idNext', '$fullname', '$age', '$gender', '$dob', '$address', '$appointment', '$status')";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return false;
}

function appPatient($_appointment, $PatientID)
{
    include 'config.php';

    $sql = "UPDATE Patient set Appointment='$_appointment', Status='Waiting' WHERE PatientID = '$PatientID'";

    if (mysqli_query($conn, $sql)) return true;
    else echo "Error creating table: " . mysqli_error($conn);
}


function getAllPatientData()
{
    include 'config.php';

    $sql = "SELECT * FROM Patient ORDER BY PatientID";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return null;
}

function getPatientByPatientID($_id)
{
    include 'config.php';

    $sql = "SELECT * FROM Patient WHERE PatientID = '$_id'";

    if ($result = mysqli_query($conn, $sql)) {
        return mysqli_fetch_assoc($result);
    } else return null;
}

function getMedIDNext()
{
    include 'config.php';

    $sql = "SELECT * FROM MedRec ORDER BY MedID desc LIMIT 1";
    if ($result = mysqli_query($conn, $sql)) {
        date_default_timezone_set('Asia/Jakarta');
        $date = date("Ymd");
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $today = (int)substr($row['MedID'], 0, 8);
            if ($today == $date) {
                $idNext = (int)$row['MedID'] + 1;
            } else {
                $idNext = $date. '00001';
            }
        }else {
            $idNext = $date. '00001';
        }
    }
    return $idNext;
}

function addMedRec($appointment, $PatientID, $fullname, $description)
{
    include 'config.php';

    $idNext = getMedIDNext();

    $sql = "INSERT INTO MedRec VALUES ('$idNext', '$PatientID', '$fullname', '$appointment', '$description')";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return false;
}

function getAllMedRecData()
{
    include 'config.php';

    $sql = "SELECT * FROM MedRec ORDER BY MedID";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return null;
}

function getMedRecByDate($_date)
{
    include 'config.php';

    $sql = "SELECT * FROM MedRec WHERE AppDate = '$_date'";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return null;
}

function getAppointmentDataByDate($_date)
{
    include 'config.php';

    $sql = "SELECT * FROM Patient WHERE Appointment = '$_date' and Status = 'Waiting'";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return null;

}

function updateStatus($_id)
{
    include 'config.php';

    $sql = "UPDATE Patient set Status = 'Done' WHERE PatientID = '$_id'";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return null;
}

function getMedRecByName($_name)
{
    include 'config.php';

    $sql = "SELECT * FROM MedRec WHERE FullName = '$_name'";

    if ($result = mysqli_query($conn, $sql)) return $result;
    else return null;
}

function getTodayDate()
{
    date_default_timezone_set('Asia/Jakarta');
    $today = date("D, j F Y");
    return $today;
}

function countApp()
{
    include 'config.php';

    date_default_timezone_set('Asia/Jakarta');

    $today = date('Y-m-d');

    $sql = "SELECT COUNT(PatientID) As total FROM Patient WHERE Status = 'Waiting' and Appointment = '$today'";

    if ($result = mysqli_query($conn, $sql)) 
    {
        $values = mysqli_fetch_assoc($result);
        $num_rows = (string)$values['total'];

        return $num_rows;

    } else return null;
}

?> 