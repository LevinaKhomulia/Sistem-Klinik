<?php include 'mod-user.php' ?>

<?php if (isset($_GET['id'])) $data = getPatientByPatientID($_GET['id']) ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <div class="page-wrapper">
         <!-- MENU SIDEBAR-->
         <?php include "doc-sidebar.php" ?>
        <!-- END MENU SIDEBAR-->
        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <?php include "header.php" ?>
            <!-- END HEADER DESKTOP-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Form Medical Record</strong>
                                    </div>
                                    <div class="card-body card-block">
                                       
                                        <?php $submitPath = 'con-pat-regis.php' ?>
                                        <form action="<?php echo $submitPath . "?page=medical"?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                                        <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Date</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" id="pt_date" name="pt_date" placeholder="Text" class="form-control" value="<?php echo $data['Appointment']?>" readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class="form-control-label">Patient ID</label>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <input type="text" id="pt_id" name="pt_id" placeholder="Text" class="form-control" value="<?php echo $data['PatientID']?>"readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Name</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_name" name="pt_name" placeholder="Text" class="form-control" value="<?php echo $data['FullName']?>"readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Age</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_age" name="pt_age" placeholder="Text" class="form-control" value="<?php echo $data['Age']?>" readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Gender</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_gender" name="pt_gender" placeholder="Text" class="form-control" value="<?php echo $data['Gender']?>" readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Description</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <textarea name="pt_desc" id="pt_desc" cols="30" rows="10" class="form-control" required></textarea>
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <button type="submit" name="Submit" value="medrec" class="btn btn-primary btn-sm">
                                                    <i class="fa fa-dot-circle-o"></i>Submit
                                                </button>
                                               <a href="patient-app.php"><button type="button" class="btn btn-danger btn-sm">
                                                    <i class="fa fa-ban"></i>Cancel
                                                </button></a> 
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END PAGE CONTAINER-->
                </div>
            </div>
            <?php include "footer.php" ?>
</body>

</html>
<!-- end document-->