<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php include "sidebar.php" ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <?php include "header.php" ?>
            <!-- END HEADER DESKTOP-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Registration Form</strong>
                                    </div>
                                    <div class="card-body card-block">
                                        <?php $submitPath = 'con-pat-regis.php'; ?>
                                        <form action="<?php echo $submitPath . "?page=regis" ?>" method="POST" enctype="multipart/form-data" class="form-horizontal" onsubmit="return validate()">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Name</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_name" name="pt_name" placeholder="Text" class="form-control" >
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Age</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_age" name="pt_age" placeholder="Text" class="form-control" >
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Gender</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_gender" name="pt_gender" placeholder="Text" class="form-control" >
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Date of Birth</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" id="pt_dob" name="pt_dob" placeholder="Text" class="form-control" >
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Address</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_address" name="pt_address" placeholder="Text" class="form-control" >
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <button type="submit" name="Submit" value="register" class="btn btn-primary btn-sm">
                                                    <i class="fa fa-dot-circle-o"></i> Register
                                                </button>
                                             <a href="user-register.php"><button type="button" class="btn btn-danger btn-sm"> 
                                                    <i class="fa fa-ban"></i>Cancel
                                                </button></a>   
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END PAGE CONTAINER-->
                </div>
            </div>
            <?php include "footer.php" ?>

            <script>
            function validate() {
                var pt_name = document.getElementById("pt_name").value;
                var pt_age = document.getElementById("pt_age").value;
                var pt_gender = document.getElementById("pt_gender").value;
                var pt_dob = document.getElementById("pt_dob").value;
                var pt_address = document.getElementById("pt_dob").value;

                if(pt_name != "" && pt_age != "" && pt_gender != "" && pt_dob != "" && pt_address != "") return true;
                else {
                    alert("Please fill in all required fields...");
                    return false;
                }   
            }
            </script>
</body>
</html>
<!-- end document-->