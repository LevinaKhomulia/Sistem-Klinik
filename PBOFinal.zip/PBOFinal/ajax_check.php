<?php
include 'config.php';

$_PatientID = $_POST['PatientID'];

$allData = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM Patient WHERE PatientID = '$_PatientID'"));
// $allData = mysqli_fetch_array(mysqli_query($conn, "SELECT * FROM patient WHERE PatientID = '$_PatientID'"));

$dataItem = array('fullname' => $allData['FullName'], 
                    'age' => $allData['Age'],
                    'gender' => $allData['Gender'],
                    'dob' => $allData['DOB'],
                    'address' => $allData['Address']);

echo json_encode($dataItem);
