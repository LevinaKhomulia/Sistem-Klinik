 <aside class="menu-sidebar2">
     <div class="logo" style='background: #4272D7;'> 
         <!-- <a href="#">
             <img src="images/icon/logo-white.png" alt="Cool Admin" />
         </a> -->
     </div>
     <div class="menu-sidebar2__content js-scrollbar1">
         <div class="account2">
             <div class="image -120">
                 <img src="images/icon/Clinic-Logo.png" alt="" />
                 <h2 class="name" align="center">Admin</h2>
             </div>
            
             <a href="<?php echo 'con-pat-regis.php?page=logout';?>">Sign out</a>
         </div>
         <nav class="navbar-sidebar2">
             <ul class="list-unstyled navbar__list">
                 <li>
                     <a href="index2.php">
                         <i class="fas fa-home"></i>Home</a>
                 </li>
                 <li>
                     <a href="user-register.php">
                         <i class="fa fa-user-plus"></i>Register</a>
                 </li>
                 <li>
                     <a href="user-appointment.php">
                         <i class="fas fa-edit"></i>Appointment</a>
                 </li>
             </ul>
         </nav>
     </div>
 </aside>