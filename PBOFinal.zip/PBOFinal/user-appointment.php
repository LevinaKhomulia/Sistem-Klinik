<?php include 'mod-user.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php include "sidebar.php" ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <?php include "header.php" ?>
            <!-- END HEADER DESKTOP-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">
                                        <strong>Appointment Form</strong>
                                    </div>
                                    <div class="card-body card-block">
                                        <?php $submitPath = 'con-pat-regis.php' ?>
                                        <form action="<?php echo $submitPath . "?page=app" ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class="form-control-label">Patient ID</label>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <input type="text" id="pt_id" name="pt_id" placeholder="Text" class="form-control" required>
                                                </div>
                                                <div class="col-12 col-md-3">
                                                    <button type="button" name="search" id="search" class="btn btn-secondary">Search Patient</button>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Name</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_name" name="pt_name" placeholder="Text" class="form-control" readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Age</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_age" name="pt_age" placeholder="Text" class="form-control" readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Gender</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_gender" name="pt_gender" placeholder="Text" class="form-control" readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Date of Birth</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" id="pt_dob" name="pt_dob" placeholder="Text" class="form-control" readonly>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Address</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="pt_address" name="pt_address" placeholder="Text" class="form-control" readonly>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Appointment</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="date" id="pt_app" name="pt_app" placeholder="Text" class="form-control" onchange="checkDate()" required>
                                                </div>
                                            </div>
                                            <div class="card-footer">
                                                <button type="submit" name="Submit" value="appointment" id="appointment" class="btn btn-primary btn-sm" disabled>
                                                    <i class="fa fa-dot-circle-o"></i> Appointment
                                                </button>
                                                <a href="user-appointment.php"><button type="button" class="btn btn-danger btn-sm">
                                                        <i class="fa fa-ban"></i> Cancel
                                                    </button></a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END PAGE CONTAINER-->
                </div>
            </div>
            <?php include "footer.php" ?>

            <script>
                $('#search').click(function() {
                    $.ajax({
                        type: 'POST',
                        url: 'ajax_check.php',
                        dataType: 'json',
                        data: {
                            PatientID: $("#pt_id").val()
                        },
                        success: (function(data) {
                            $('#pt_name').val(data.fullname);
                            $('#pt_age').val(data.age);
                            $('#pt_gender').val(data.gender);
                            $('#pt_dob').val(data.dob);
                            $('#pt_address').val(data.address);
                            if ($('#pt_address').val() != "")
                                $('#appointment').prop('disabled', false);
                            else
                                $('#appointment').prop('disabled', true);
                        })
                    })
                });

                function checkDate() {
                    var selectedText = document.getElementById('pt_app').value;
                    var selectedDate = new Date(selectedText);
                    var now = new Date();
                    now = now.setDate(now.getDate() -1 );
                    if (selectedDate < now) {
                        alert("Date must be in the future");
                    }
                }
            </script>
</body>

</html>
<!-- end document-->