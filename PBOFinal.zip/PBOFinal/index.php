<?php include 'mod-user.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php include "sidebar.php" ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <?php include "header.php" ?>
            <!-- END HEADER DESKTOP-->

            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">

                            <div class="col-lg-12 m-b-30">
                                <div class="input-group">
                                    <input class="form-control border-secondary py-2" type="search" placeholder="search" id="search">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary" type="button" disabled>
                                            <i class="fa fa-search"></i>
                                        </button>
                                    </div>
                                </div>
                            </div> 

                            <div class="col-lg-12">
                                <div class="table-responsive table--no-card m-b-30">
                                    <table class="table table-borderless table-striped table-earning">
                                        <thead>
                                            <tr>
                                                <th>Patien ID</th>
                                                <th>Name</th>
                                                <th>Age</th>
                                                <th>Gender</th>
                                                <th>DOB</th>
                                                <th>Address</th>
                                            </tr>
                                        </thead>
                                        <tbody id="myTable">
                                            <?php $getAllData = getAllPatientData();
                                                if($getAllData != null) {
                                                    foreach($getAllData as $data) { ?>
                                                        <tr>
                                                        <td><?php echo $data['PatientID'] ?></td>
                                                        <td><?php echo $data['FullName'] ?></td>
                                                        <td><?php echo $data['Age'] ?></td>
                                                        <td><?php echo $data['Gender'] ?></td>
                                                        <td><?php echo $data['DOB'] ?></td>
                                                        <td><?php echo $data['Address'] ?></td>
                                                   <?php }
                                                } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- END PAGE CONTAINER-->
        </div>
    </div>

    <?php include "footer.php" ?>


<script>
    $(document).ready(function(){
        $("#search").on("keyup", function() {
        var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
        });
    });
</script>


</body>

</html>
<!-- end document-->