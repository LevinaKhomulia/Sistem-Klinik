<?php include 'mod-user.php' ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "head.php" ?>
</head>

<body>
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php include "doc-sidebar.php" ?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <?php include "header.php" ?>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">Patients' Appointments</h3>

                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                <th>Appointment Date</th>
                                                <th>Patient ID</th>
                                                <th>Full Name</th>
                                                <th>Age</th>
                                                <th>Gender</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php 
                                            date_default_timezone_set('Asia/Jakarta');
                                            $getAllData = getAppointmentDataByDate(date('Y-m-d'));

                                            if ($getAllData != null) {
                                                    foreach ($getAllData as $data) { ?>
                                                    <tr>
                                                        <td><?php echo $data['Appointment'] ?></td>
                                                        <td><?php echo $data['PatientID'] ?></td>
                                                        <td><?php echo $data['FullName'] ?></td>
                                                        <td><?php echo $data['Age'] ?></td>
                                                        <td><?php echo $data['Gender'] ?></td>
                                                        <td> 
                                                        <form action="add-medrec.php?id=<?php echo $data['PatientID']?>" method="post">    
                                                        <button type="submit" class="item"data-toggle="tooltip" data-placement="top" title="Add Medical Record">
                                                              <i class="fa fa-stethoscope"> Add</i></button>
                                                        </form>
                                                        </td>
                                                    </tr>
                                                    <tr class="spacer"></tr>
                                          <?php  }
                                              } ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PAGE CONTAINER-->
        </div>
    </div>

    <?php include "footer.php" ?>

</body>

</html>
<!-- end document-->