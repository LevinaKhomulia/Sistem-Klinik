<aside class="menu-sidebar2">
    <div class="logo" style='background: #4272D7;'>
        <!-- <a href="doc-index.php">
            <img src="images/icon/logoBG.png" alt="Cool Admin" />
        </a> -->
    </div>
    <div class="menu-sidebar2__content js-scrollbar1">
        <div class="account2">
            <div class="image">
                <img src="images/icon/Clinic-Logo.png" alt="" />
            </div>
            <h4 class="name">Doctor</h4>
            <a href="<?php echo 'con-pat-regis.php?page=logout'; ?>">Sign out</a>
        </div>
        <nav class="navbar-sidebar2">
            <ul class="list-unstyled navbar__list">
                <li>
                    <a href="doc-index.php">
                        <i class="fas fa-home"></i>Home</a>
                </li>
                <li>
                    <a href="patient-app.php">
                        <i class="fa fa-calendar"></i>Booked Appointment</a>
                </li>
                <li>
                    <a href="checkup-history.php">
                        <i class="fa fa-history"></i>History</i></a>
                </li>
            </ul>
        </nav>
    </div>
</aside>