<?php

$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "Clinic";

// $serverName = "localhost:3308";
// $userName = "root";
// $password = "1234";
// $dbName = "clinic";


$conn = new mysqli($serverName, $userName, $password, $dbName);

if (!$conn) die("Error Connection : " . mysqli_connect_error());

?>