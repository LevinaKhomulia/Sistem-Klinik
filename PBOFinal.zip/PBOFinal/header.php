<header class="header-desktop2">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="header-wrap2">
                <!-- <div class="logo d-block d-lg-none">
                    <a href="#">
                        <img src="images/icon/clinic-logo.jpg" alt="CoolAdmin" />
                    </a>
                </div> -->
                <div class="header-button2">
                    <div class="header-button-item">
                       <a href ="<?php echo 'con-user-login.php?page=logout'?>"><i class="fas fa-sign-out-alt"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- <aside class="menu-sidebar2 js-right-sidebar d-block d-lg-none">
    <div class="logo">
        <a href="#">
            <img src="images/icon/Clinic-Logo.png" alt="Cool Admin" />
        </a>
    </div>
    <div class="menu-sidebar2__content js-scrollbar2">
        <div class="account2">
            <div class="image img-cir img-120">
                <img src="images/icon/avatar-big-01.jpg" alt="John Doe" />
            </div>
            <h4 class="name"></h4>
        </div>

    </div>
</aside> -->